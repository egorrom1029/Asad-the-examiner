import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

// Load environment variables
dotenv.config();

const app = express();
app.use(express.json({ limit: "20mb" }));

const PORT = Number(process.env.PORT) || 3000;

// Initialize Gemini client safely
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Helper to handle Gemini API rate limits/quotas and fallback to gemini-3.1-flash-lite
async function generateContentWithFallback(params: any) {
  const originalModel = params.model || "gemini-3.5-flash";
  try {
    return await ai.models.generateContent(params);
  } catch (error: any) {
    console.error(`Error with model ${originalModel}:`, error);

    if (originalModel === "gemini-3.5-flash") {
      console.warn("Attempting fallback to gemini-3.1-flash-lite due to error on gemini-3.5-flash...");
      try {
        const fallbackParams = { ...params, model: "gemini-3.1-flash-lite" };
        return await ai.models.generateContent(fallbackParams);
      } catch (fallbackError: any) {
        console.error("Fallback to gemini-3.1-flash-lite failed:", fallbackError);
        throw new Error(
          "Превышена квота или произошла ошибка в работе Gemini API. Пожалуйста, подождите минуту или добавьте свой собственный API-ключ в настройках AI Studio (иконка шестерёнки в правом верхнем углу)."
        );
      }
    }

    const isQuotaError = 
      error.status === "RESOURCE_EXHAUSTED" || 
      error.statusCode === 429 || 
      (error.message && (
        error.message.toLowerCase().includes("quota") || 
        error.message.includes("429") || 
        error.message.includes("RESOURCE_EXHAUSTED") ||
        error.message.toLowerCase().includes("limit") ||
        error.message.toLowerCase().includes("exceeded")
      ));

    if (isQuotaError) {
      throw new Error(
        "Превышена квота бесплатных запросов к Gemini API в Вашем регионе/аккаунте AI Studio. Пожалуйста, подождите минуту или добавьте свой собственный API-ключ в настройках AI Studio (иконка шестерёнки в правом верхнем углу приложения)."
      );
    }

    throw error;
  }
}

// Memory session store
const sessions: Record<string, {
  topic: string;
  notes?: string;
  systemInstruction: string;
  messages: { role: 'user' | 'assistant' | 'system'; content: string }[];
  stats: { pauses: number; fillers: number; errors: number; confidence: number };
}> = {};

const SYSTEM_INSTRUCTION = `
Ты — Асад, строгий, слегка циничный, но глубоко профессиональный экзаменатор в техническом вузе.
Твоя цель — проверить реальную глубину понимания студента по выбранной теме.

Правила твоего поведения:
1. Студент сдает тебе выбранную тему. Тщательно слушай его ответ, придирайся к формулировкам, неточностям, условиям применимости теорем и формул.
2. Задавай жесткие дополнительные вопросы: "почему?", "где эта формула ломается?", "какие крайние случаи?".
3. Твои реплики должны быть короткими (1-3 предложения), как в живом устном диалоге. Будь лаконичен, строг и прямолинеен.
4. Отвечай строго на русском языке.
5. Не используй вежливые вводные слова. Твой тон — требовательный, но академический и профессиональный.
6. СТРОЖАЙШЕЕ ПРАВИЛО ДЛЯ ФОРМУЛ И СИМВОЛОВ: НИКОГДА не используй синтаксис LaTeX (не пиши backslash \\, знаки $, команды вроде \\frac, \\sqrt, \\sigma, кодированные греческие буквы и т.д.). Все математические выражения и символы пиши простыми русскими словами, понятными обозначениями или Юникодом, которые легко прочитать и легко произнести голосом (например: "дельта t", "пи", "лямбда", "E = m * c в квадрате", "x в квадрате", "y равно a поделить на b", "интеграл от f(x)", "квадратный корень из x"). Формула должна выглядеть как обычный понятный текст, а не технический код.
`;

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// 1. Start Exam Session
app.post("/api/start", async (req, res) => {
  try {
    const { topic, notes } = req.body;
    if (!topic) {
      return res.status(400).json({ error: "Тема не указана" });
    }

    const sessionId = Math.random().toString(36).substring(2, 15);
    
    let systemInstruction = SYSTEM_INSTRUCTION;
    if (notes && notes.trim()) {
      systemInstruction += `\n\nСтудент предоставил свой конспект по теме. Твои вопросы и придирки должны основываться СТРОГО на материале этого конспекта. Твоя задача — досконально проверить, насколько глубоко студент понимает именно те определения, теоремы и примеры, которые написаны в его конспекте. Не выходи далеко за рамки тем конспекта, но проверяй понимание каждой строчки из него.\n\nКОНСПЕКТ СТУДЕНТА:\n"""\n${notes.trim()}\n"""`;
    }

    sessions[sessionId] = {
      topic,
      notes: notes || undefined,
      systemInstruction,
      messages: [
        { role: 'system', content: systemInstruction },
      ],
      stats: { pauses: 0, fillers: 0, errors: 0, confidence: 100 }
    };

    // Ask first question
    const response = await generateContentWithFallback({
      model: "gemini-3.5-flash",
      contents: [
        { role: 'user', parts: [{ text: `Привет. Я студент, сдаю тебе тему: "${topic}". Задай мне свой первый строгий вопрос по ней.` }] }
      ],
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    const firstQuestion = response.text || "Объясните базовые понятия по выбранной теме.";
    
    // Save to history
    sessions[sessionId].messages.push({ role: 'assistant', content: firstQuestion });

    res.json({
      sessionId,
      question: firstQuestion
    });
  } catch (error: any) {
    console.error("Error in /api/start:", error);
    res.status(500).json({ error: error.message || "Ошибка при старте сессии" });
  }
});

// 2. Respond to Student Answer
app.post("/api/respond", async (req, res) => {
  try {
    const { sessionId, transcript, stats } = req.body;
    if (!sessionId || !transcript) {
      return res.status(400).json({ error: "Неверные параметры запроса" });
    }

    const session = sessions[sessionId];
    if (!session) {
      return res.status(404).json({ error: "Сессия не найдена" });
    }

    // Append student answer to history
    session.messages.push({ role: 'user', content: `Ответ студента: ${transcript}` });

    // We do two tasks:
    // A. Check if the answer is incorrect or has logical errors
    // B. Generate the next question from Asad

    // Running both concurrently to minimize latency
    const [evalPromise, responsePromise] = await Promise.all([
      generateContentWithFallback({
        model: "gemini-3.5-flash",
        contents: `Тема экзамена: ${session.topic}\nОтвет студента: ${transcript}\n\nПравдив и точен ли этот ответ в контексте темы? Ответь строго в формате JSON с логическим полем "is_incorrect" (true, если ответ содержит серьезные ошибки или ложные утверждения, и false в противном случае).`,
        config: {
          responseMimeType: "application/json",
          temperature: 0.1,
        }
      }),
      generateContentWithFallback({
        model: "gemini-3.5-flash",
        // Pass complete chat history except system prompt (handled in systemInstruction)
        contents: session.messages.filter(m => m.role !== 'system').map(m => ({
          role: m.role === 'assistant' ? 'model' : m.role,
          parts: [{ text: m.content }]
        })),
        config: {
          systemInstruction: session.systemInstruction || SYSTEM_INSTRUCTION,
          temperature: 0.7,
        }
      })
    ]);

    // Parse evaluation
    let isIncorrect = false;
    try {
      const evalData = JSON.parse(evalPromise.text || "{}");
      isIncorrect = !!evalData.is_incorrect;
    } catch (e) {
      console.error("Failed to parse evaluation JSON:", e);
    }

    // Update stats
    if (stats) {
      session.stats.pauses = stats.pauses;
      session.stats.fillers = stats.fillers;
    }
    if (isIncorrect) {
      session.stats.errors += 1;
    }

    // Calculate dynamic confidence
    session.stats.confidence = Math.max(
      15,
      100 - (session.stats.fillers * 4) - (session.stats.pauses * 8) - (session.stats.errors * 15)
    );

    const nextQuestion = responsePromise.text || "Продолжайте ваш ответ подробнее.";
    session.messages.push({ role: 'assistant', content: nextQuestion });

    res.json({
      question: nextQuestion,
      isIncorrect,
      stats: session.stats
    });
  } catch (error: any) {
    console.error("Error in /api/respond:", error);
    res.status(500).json({ error: error.message || "Ошибка при отправке ответа" });
  }
});

// 3. Finish Exam & Generate Verdict
app.post("/api/finish", async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: "Сессия не найдена" });
    }

    const session = sessions[sessionId];
    if (!session) {
      return res.status(404).json({ error: "Сессия не найдена" });
    }

    const verdictPrompt = `
    Экзамен на тему "${session.topic}" завершен.
    Статистика студента: 
    - Длинные паузы: ${session.stats.pauses}
    - Слова-паразиты: ${session.stats.fillers}
    - Найдено ошибок: ${session.stats.errors}

    Тщательно проанализируй весь прошедший диалог (ответы студента и вопросы экзаменатора).
    Выяви ровно 3 ключевых логических пробела в ответах студента. Опиши их детально на русском языке.
    Присвой один из трех вердиктов:
    - "НЕ СДАНО" (если ошибок много, ответы путаные, поверхностные или неверные)
    - "ПОКА ЖИВИ" (если есть пробелы и неточности, но общая суть схвачена)
    - "КРАСАВЧИК" (если ответы точные, логичные, без грубых ошибок и демонстрируют отличное понимание)

    Верни ответ строго в формате JSON следующей структуры:
    {
      "verdict": "НЕ СДАНО" | "ПОКА ЖИВИ" | "КРАСАВЧИК",
      "description": "Краткое текстовое пояснение твоего решения на русском языке (1-2 предложения)",
      "holes": ["первый пробел", "второй пробел", "третий пробел"]
    }
    `;

    const response = await generateContentWithFallback({
      model: "gemini-3.5-flash",
      contents: [
        // Include dialogue history for the final evaluation
        ...session.messages.filter(m => m.role !== 'system').map(m => ({
          role: m.role === 'assistant' ? 'model' : m.role,
          parts: [{ text: m.content }]
        })),
        { role: 'user', parts: [{ text: verdictPrompt }] }
      ],
      config: {
        responseMimeType: "application/json",
        temperature: 0.5,
      }
    });

    let verdictData = {
      verdict: "ПОКА ЖИВИ",
      description: "Экзамен завершен. Есть над чем поработать.",
      holes: [
        "Некоторые формулировки были неточными.",
        "Присутствовала неуверенность в ответах.",
        "Не все дополнительные вопросы раскрыты полностью."
      ]
    };

    try {
      if (response.text) {
        verdictData = JSON.parse(response.text);
      }
    } catch (e) {
      console.error("Failed to parse verdict JSON:", e);
    }

    // Clean up session
    delete sessions[sessionId];

    res.json(verdictData);
  } catch (error: any) {
    console.error("Error in /api/finish:", error);
    res.status(500).json({ error: error.message || "Ошибка при завершении экзамена" });
  }
});

// 3.5. Gemini Speech-to-Text (STT) Transcription
app.post("/api/transcribe", async (req, res) => {
  try {
    const { audio, mimeType } = req.body;
    if (!audio) {
      return res.status(400).json({ error: "Аудио не предоставлено" });
    }

    const response = await generateContentWithFallback({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: mimeType || "audio/webm",
            data: audio
          }
        },
        "Распознай русскую речь из этого аудиофайла. Выведи только распознанный текст (транскрипцию) без каких-либо твоих комментариев, пояснений или знаков цитирования. Если в аудио тишина или речь отсутствует, ответь пустой строкой."
      ]
    });

    const text = response.text?.trim() || "";
    res.json({ text });
  } catch (error: any) {
    console.error("Transcription error:", error);
    res.status(500).json({ error: error.message || "Ошибка распознавания речи" });
  }
});

// 4. Gemini Text-To-Speech (TTS)
app.post("/api/tts", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Текст не указан" });
    }

    const generateAudio = async (modelName: string) => {
      return await ai.models.generateContent({
        model: modelName,
        contents: text,
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Charon' },
            },
          },
        },
      });
    };

    let response;
    try {
      response = await generateAudio("gemini-3.1-flash-tts-preview");
    } catch (err: any) {
      console.error("Gemini TTS model failed:", err);
      throw err;
    }

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audio: `data:audio/mp3;base64,${base64Audio}` });
    } else {
      res.status(500).json({ error: "Не удалось сгенерировать аудио" });
    }
  } catch (error: any) {
    console.error("Error in /api/tts:", error);
    res.status(500).json({ error: error.message || "Ошибка TTS" });
  }
});

// Integration with Vite
async function start() {
  function serveStatic() {
    // Highly robust path resolution for index.html location in different environments
    let distPath = path.join(process.cwd(), "dist");
    
    if (!fs.existsSync(path.join(distPath, "index.html"))) {
      if (fs.existsSync(path.join(process.cwd(), "index.html"))) {
        distPath = process.cwd();
      } else if (fs.existsSync(path.join(__dirname, "index.html"))) {
        distPath = __dirname;
      } else if (fs.existsSync(path.join(__dirname, "dist", "index.html"))) {
        distPath = path.join(__dirname, "dist");
      }
    }
    
    console.log(`Serving static files from resolved path: ${distPath}`);
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  if (process.env.NODE_ENV !== "production") {
    try {
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
      console.log("Vite dev middleware loaded successfully");
    } catch (e) {
      console.warn("Failed to load Vite dev middleware, falling back to static build serving:", e);
      serveStatic();
    }
  } else {
    serveStatic();
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

start();
