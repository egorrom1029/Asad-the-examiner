export interface ExamStats {
  pauses: number;
  fillers: number;
  confidence: number;
  errors: number;
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ExamSession {
  sessionId: string;
  topic: string;
  messages: Message[];
  stats: ExamStats;
  startTime: number;
}

export interface VerdictResult {
  verdict: 'НЕ СДАНО' | 'ПОКА ЖИВИ' | 'КРАСАВЧИК';
  description: string;
  holes: string[];
}

